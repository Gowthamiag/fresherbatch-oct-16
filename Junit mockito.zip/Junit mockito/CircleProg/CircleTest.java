import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CircleTest {

		Circle c1= new Circle(12);
		@Test
		void testgetRadius() {
			assertEquals(12,c1.getRadius(),0.0001);
			
		}
		@Test
		void testgetArea() {
			assertEquals(Math.PI*(12*12),c1.getArea(),0.0001);
			
			

		}
		@Test
		void testgetCircumference() {
			assertEquals(Math.PI*2*12,c1.getCircumference(),0.0001);
			
	}

}
