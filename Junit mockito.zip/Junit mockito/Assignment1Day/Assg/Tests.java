package Assg;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Tests {

	@Test
		final void testCustomer() {
			Customer c1=new Customer("gow","111",5000);
			String expected="gow";
			assertEquals("gow",c1.getName(),"The  getName will print the customer balance");
			String expected2nd="111";
			assertEquals("111",c1.getIdno(),"The getIdno will print the customer balance");
			int expectedbal=5000;
			assertEquals(5000,c1.getBalance(),"The  getBalance will print the customer balance");
			
		}
		@Test
		void testItem() {
			Item a1=new Item( "cake","21",2,200.0);
			String expected="cake";
			assertEquals("cake",a1.getItemName(),"The  getItemName will print the customer balance");
			String expected2nd="21";
			assertEquals("21",a1.getItemno(),"The getItemno will print the customer balance");
			int expectedqty=2;
			assertEquals(2,a1.getItemquantity(),"The getItemquantity will print the customer balance");
			double expectedprc=200.0;
			assertEquals(200.0,a1.getPrice(),"The  getprice will print the customer balance");
			
		}
		
		

	}


