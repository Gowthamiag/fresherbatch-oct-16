package Assg;

public class TestTax {
	public static void main(String[] args) 
	{
		TaxOnSalary t1=new TaxOnSalary(true);
		TaxOnSalary t2=new TaxOnSalary(true);
		t1.inputsalary();
		System.out.println("Tax1  :"   +t1.calculateTax());
		
	}

}
